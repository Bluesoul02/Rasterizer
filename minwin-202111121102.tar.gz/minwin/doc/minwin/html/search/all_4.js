var searchData=
[
  ['elapsed_5ftime_12',['elapsed_time',['../classminwin_1_1Clock.html#aed89af03bf61aba21dc826de7694b342',1,'minwin::Clock']]]
];
