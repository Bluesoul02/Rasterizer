var searchData=
[
  ['_7ewindow_125',['~Window',['../classminwin_1_1Window.html#a245d821e6016fa1f6970ccbbedd635f6',1,'minwin::Window']]]
];
