var searchData=
[
  ['g_128',['g',['../classminwin_1_1Color.html#af9658b6eaae3fef9f3f49aad4697926a',1,'minwin::Color']]]
];
