var searchData=
[
  ['b_1',['b',['../classminwin_1_1Color.html#a9871d27d6e05b6e319c5de83d10ea1a4',1,'minwin::Color']]]
];
