var searchData=
[
  ['deprecated_20list_10',['Deprecated List',['../deprecated.html',1,'']]],
  ['display_11',['display',['../classminwin_1_1Window.html#afadfafa5a0b9472554759004aafb327e',1,'minwin::Window']]]
];
