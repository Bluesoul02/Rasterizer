var searchData=
[
  ['get_5fcolor_91',['get_color',['../classminwin_1_1Text.html#a6665e26311431bdca4cd912cc945dff7',1,'minwin::Text']]],
  ['get_5fdraw_5fcolor_92',['get_draw_color',['../classminwin_1_1Window.html#a917005ed0989dd0fe0912bfd84391b3b',1,'minwin::Window']]],
  ['get_5fheight_93',['get_height',['../classminwin_1_1Window.html#a81a7acd7437d120a48b8a39ab1cbd645',1,'minwin::Window']]],
  ['get_5fposx_94',['get_posX',['../classminwin_1_1Text.html#a244d3b4464e7495dbe63832762b8af67',1,'minwin::Text']]],
  ['get_5fposy_95',['get_posY',['../classminwin_1_1Text.html#a58f1c43dc20bcdd05263cf17425276d1',1,'minwin::Text']]],
  ['get_5fstring_96',['get_string',['../classminwin_1_1Text.html#a2cce6c3260516215afe58d7bb0d14d6f',1,'minwin::Text']]],
  ['get_5ftitle_97',['get_title',['../classminwin_1_1Window.html#ac3c339cfa2aefca007a16ac90ad25f6c',1,'minwin::Window']]],
  ['get_5fwidth_98',['get_width',['../classminwin_1_1Window.html#a9c4efc06a4aed37198a48a67a8beccb0',1,'minwin::Window']]]
];
