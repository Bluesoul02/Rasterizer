var searchData=
[
  ['mwexception_69',['MWException',['../classminwin_1_1MWException.html',1,'minwin']]],
  ['mwfontexception_70',['MWFontException',['../classminwin_1_1MWFontException.html',1,'minwin']]]
];
